### Card Shuffle Test



-  Write a method, function, or procedure that sorts a standard deck of 52 playing cards in ascending order. You are free to determine what the term “ascending order” means for a deck of cards, but be ready to discuss your choice during the interview.

-  Write a method, function, or procedure that randomly shuffles a standard deck of 52 playing cards.
 
- Please create unit tests for your work.
  

