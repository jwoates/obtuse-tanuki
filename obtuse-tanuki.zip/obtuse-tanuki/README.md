### Instructions

make a fork of this repo, inside each test directory, follow the test instructions and add your files there.

When complete makea a pull request to master.
